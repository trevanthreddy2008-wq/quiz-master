package com.quizmaster.trivia.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.quizmaster.trivia.databinding.ActivityLoginBinding
import com.quizmaster.trivia.utils.PrefsManager

/**
 * Fully local email/password login - no Google, no Firebase, no backend.
 * Accounts are stored (hashed) only on this device via PrefsManager.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (PrefsManager.getSignedInEmail(this) != null) {
            goToMain()
            return
        }

        binding.btnLogin.setOnClickListener { onLoginClicked() }
        binding.btnCreateAccount.setOnClickListener { onCreateAccountClicked() }
    }

    private fun onLoginClicked() {
        val email = binding.etEmail.text.toString()
        val password = binding.etPassword.text.toString()

        if (email.isBlank() || password.isBlank()) {
            showError("Enter your email and password")
            return
        }

        if (PrefsManager.login(this, email, password)) {
            goToMain()
        } else {
            showError("Incorrect email or password")
        }
    }

    private fun onCreateAccountClicked() {
        val email = binding.etEmail.text.toString()
        val password = binding.etPassword.text.toString()

        val error = PrefsManager.signUp(this, email, password)
        if (error == null) {
            goToMain()
        } else {
            showError(error)
        }
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
