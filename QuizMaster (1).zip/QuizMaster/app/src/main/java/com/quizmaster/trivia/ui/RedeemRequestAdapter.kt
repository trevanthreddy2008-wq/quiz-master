package com.quizmaster.trivia.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizmaster.trivia.R
import com.quizmaster.trivia.databinding.ItemRedeemHistoryBinding
import com.quizmaster.trivia.model.RedeemRequest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RedeemRequestAdapter(
    private var items: List<RedeemRequest>,
    private val onMarkReceived: (String) -> Unit
) : RecyclerView.Adapter<RedeemRequestAdapter.RequestViewHolder>() {

    private val dateFormat = SimpleDateFormat("MMM d, yyyy, h:mm a", Locale.getDefault())

    fun updateData(newItems: List<RedeemRequest>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): RequestViewHolder {
        val binding = ItemRedeemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RequestViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RequestViewHolder, position: Int) {
        holder.bind(items[position])
    }

    inner class RequestViewHolder(private val binding: ItemRedeemHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(request: RedeemRequest) {
            val context = binding.root.context
            binding.tvRequestId.text = request.requestId

            if (request.fulfilled) {
                binding.tvStatus.text = context.getString(R.string.status_fulfilled)
                binding.tvDue.text = dateFormat.format(Date(request.timestampMillis))
                binding.btnMarkReceived.visibility = View.GONE
            } else {
                binding.tvStatus.text = context.getString(R.string.status_pending)
                binding.tvDue.text = context.getString(
                    R.string.due_by_format,
                    dateFormat.format(Date(request.dueByMillis))
                )
                binding.btnMarkReceived.visibility = View.VISIBLE
                binding.btnMarkReceived.setOnClickListener {
                    onMarkReceived(request.requestId)
                }
            }
        }
    }
}
