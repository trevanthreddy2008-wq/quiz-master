package com.quizmaster.trivia.utils

import android.content.Context
import com.quizmaster.trivia.model.RedeemRequest
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import kotlin.random.Random

/**
 * Thin wrapper around SharedPreferences holding all local game state:
 * accounts, coin balance, which level the player has unlocked up to, and
 * the history of redeem REQUESTS they've submitted.
 *
 * Login is fully local/offline - no Google, no Firebase, no server. Players
 * create an account with an email + password that's stored (hashed) only
 * on their own device. This needs zero setup from you, but be aware it's
 * not "real" security: anyone with basic Android reverse-engineering
 * skills could pull the admin password out of the compiled app, since it's
 * just a string constant in the code below. It's enough to stop a casual
 * player from guessing their way into admin, not a determined one.
 *
 * There is no backend for redeem requests either. When a player hits the
 * coin threshold, they submit a request (with some contact info) which the
 * app hands off to the owner via email/WhatsApp. The owner then manually
 * sends the player a code within ~24 hours, outside the app entirely.
 */
object PrefsManager {

    private const val PREFS_NAME = "quiz_master_prefs"
    private const val KEY_COINS = "coins"
    private const val KEY_UNLOCKED_LEVEL = "unlocked_level"
    private const val KEY_REDEEM_REQUESTS = "redeem_requests"
    private const val KEY_SIGNED_IN_EMAIL = "signed_in_email"
    private const val KEY_SIGNED_IN_NAME = "signed_in_name"
    private const val KEY_ACCOUNTS = "accounts"
    private const val COINS_PER_MILESTONE = 50
    private const val REDEEM_THRESHOLD = 1000
    private const val ADMIN_BONUS_COINS = 10000

    // The only account treated as admin, and the password required to log
    // into it. Regular sign-up is blocked from ever claiming this email
    // (see signUp below), so the only way in is knowing this password.
    const val ADMIN_EMAIL = "trevanthreddy2008@gmail.com"
    private const val ADMIN_PASSWORD = "19202175"

    fun redeemThreshold(): Int = REDEEM_THRESHOLD
    fun adminBonusCoins(): Int = ADMIN_BONUS_COINS

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // --- Local accounts (email + password, stored on-device only) -------

    private fun hash(email: String, password: String): String {
        val salted = "${email.lowercase()}::$password"
        val digest = MessageDigest.getInstance("SHA-256").digest(salted.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    /** Returns null on success, or an error message to show the user. */
    fun signUp(context: Context, email: String, password: String): String? {
        val normalized = email.trim().lowercase()
        if (normalized.isEmpty() || !normalized.contains("@")) return "Enter a valid email"
        if (password.length < 4) return "Password must be at least 4 characters"
        if (normalized == ADMIN_EMAIL.lowercase()) return "That email is reserved"

        val raw = prefs(context).getString(KEY_ACCOUNTS, "[]") ?: "[]"
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).getString("email") == normalized) {
                return "An account with that email already exists"
            }
        }

        val entry = JSONObject()
            .put("email", normalized)
            .put("passwordHash", hash(normalized, password))
        array.put(entry)
        prefs(context).edit().putString(KEY_ACCOUNTS, array.toString()).apply()

        setSignedInUser(context, normalized, normalized)
        return null
    }

    /** Returns true and signs the user in if the credentials match. */
    fun login(context: Context, email: String, password: String): Boolean {
        val normalized = email.trim().lowercase()

        if (normalized == ADMIN_EMAIL.lowercase()) {
            if (password == ADMIN_PASSWORD) {
                setSignedInUser(context, ADMIN_EMAIL, "Admin")
                return true
            }
            return false
        }

        val raw = prefs(context).getString(KEY_ACCOUNTS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val targetHash = hash(normalized, password)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            if (obj.getString("email") == normalized && obj.getString("passwordHash") == targetHash) {
                setSignedInUser(context, normalized, normalized)
                return true
            }
        }
        return false
    }

    // --- Sign-in state ---------------------------------------------------

    fun getSignedInEmail(context: Context): String? =
        prefs(context).getString(KEY_SIGNED_IN_EMAIL, null)

    fun getSignedInName(context: Context): String? =
        prefs(context).getString(KEY_SIGNED_IN_NAME, null)

    private fun setSignedInUser(context: Context, email: String, displayName: String?) {
        prefs(context).edit()
            .putString(KEY_SIGNED_IN_EMAIL, email)
            .putString(KEY_SIGNED_IN_NAME, displayName ?: email)
            .apply()
    }

    fun signOut(context: Context) {
        prefs(context).edit()
            .remove(KEY_SIGNED_IN_EMAIL)
            .remove(KEY_SIGNED_IN_NAME)
            .apply()
    }

    fun isAdmin(context: Context): Boolean =
        getSignedInEmail(context)?.equals(ADMIN_EMAIL, ignoreCase = true) == true

    fun grantAdminBonus(context: Context): Int {
        if (!isAdmin(context)) return getCoins(context)
        return addCoins(context, ADMIN_BONUS_COINS)
    }

    // --- Coins & levels ----------------------------------------------------

    fun getCoins(context: Context): Int =
        prefs(context).getInt(KEY_COINS, 0)

    fun addCoins(context: Context, amount: Int = COINS_PER_MILESTONE): Int {
        val newTotal = getCoins(context) + amount
        prefs(context).edit().putInt(KEY_COINS, newTotal).apply()
        return newTotal
    }

    /** Returns true if there were enough coins to spend, false otherwise. */
    fun spendCoins(context: Context, amount: Int): Boolean {
        val current = getCoins(context)
        if (current < amount) return false
        prefs(context).edit().putInt(KEY_COINS, current - amount).apply()
        return true
    }

    fun getUnlockedLevel(context: Context): Int =
        prefs(context).getInt(KEY_UNLOCKED_LEVEL, 1)

    /** Call when a level is completed; unlocks the next one if needed. */
    fun unlockLevel(context: Context, levelJustCompleted: Int) {
        val current = getUnlockedLevel(context)
        val nextUnlocked = (levelJustCompleted + 1).coerceAtMost(100)
        if (nextUnlocked > current) {
            prefs(context).edit().putInt(KEY_UNLOCKED_LEVEL, nextUnlocked).apply()
        }
    }

    fun getRedeemRequests(context: Context): List<RedeemRequest> {
        val raw = prefs(context).getString(KEY_REDEEM_REQUESTS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = ArrayList<RedeemRequest>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                RedeemRequest(
                    requestId = obj.getString("requestId"),
                    contactInfo = obj.getString("contactInfo"),
                    timestampMillis = obj.getLong("timestamp"),
                    coinsSpent = obj.getInt("coinsSpent"),
                    fulfilled = obj.optBoolean("fulfilled", false)
                )
            )
        }
        return list.sortedByDescending { it.timestampMillis }
    }

    /**
     * Spends [REDEEM_THRESHOLD] coins and records a new pending request.
     * Returns the new request, or null if the player didn't have enough
     * coins. [contactInfo] is whatever the player typed (email, phone,
     * WhatsApp number) so the owner knows where to send the code.
     */
    fun submitRedeemRequest(context: Context, contactInfo: String): RedeemRequest? {
        if (!spendCoins(context, REDEEM_THRESHOLD)) return null

        val request = RedeemRequest(
            requestId = generateRequestId(),
            contactInfo = contactInfo,
            timestampMillis = System.currentTimeMillis(),
            coinsSpent = REDEEM_THRESHOLD,
            fulfilled = false
        )

        val raw = prefs(context).getString(KEY_REDEEM_REQUESTS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val newEntry = JSONObject()
            .put("requestId", request.requestId)
            .put("contactInfo", request.contactInfo)
            .put("timestamp", request.timestampMillis)
            .put("coinsSpent", request.coinsSpent)
            .put("fulfilled", request.fulfilled)
        array.put(newEntry)

        prefs(context).edit().putString(KEY_REDEEM_REQUESTS, array.toString()).apply()
        return request
    }

    /** Player taps "I received my code" to tidy up their own history view. */
    fun markRequestFulfilled(context: Context, requestId: String) {
        val raw = prefs(context).getString(KEY_REDEEM_REQUESTS, "[]") ?: "[]"
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            if (obj.getString("requestId") == requestId) {
                obj.put("fulfilled", true)
            }
        }
        prefs(context).edit().putString(KEY_REDEEM_REQUESTS, array.toString()).apply()
    }

    private fun generateRequestId(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O/1/I to avoid confusion
        val block = (1..6).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        return "REQ-$block"
    }
}

