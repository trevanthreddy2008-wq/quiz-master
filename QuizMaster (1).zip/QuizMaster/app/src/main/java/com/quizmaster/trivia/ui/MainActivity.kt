package com.quizmaster.trivia.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.quizmaster.trivia.R
import com.quizmaster.trivia.data.QuestionRepository
import com.quizmaster.trivia.databinding.ActivityMainBinding
import com.quizmaster.trivia.utils.PrefsManager

class MainActivity : AppCompatActivity() {

    companion object {
        // TODO (REQUIRED BEFORE PUBLISHING): replace with your real AdMob
        // banner Ad Unit ID, created in AdMob console -> your app -> Ad
        // units -> Banner. This is Google's public TEST banner ID.
        private const val TEST_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    }

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // If somehow not signed in (e.g. signed out elsewhere), bounce back to login.
        if (PrefsManager.getSignedInEmail(this) == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        binding.coinPill.setOnClickListener {
            startActivity(Intent(this, RedeemActivity::class.java))
        }

        binding.tvSignOut.setOnClickListener {
            PrefsManager.signOut(this)
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        binding.btnAdminBonus.text = getString(R.string.admin_bonus_button_format, PrefsManager.adminBonusCoins())
        binding.btnAdminBonus.setOnClickListener {
            PrefsManager.grantAdminBonus(this)
            Toast.makeText(this, getString(R.string.admin_bonus_granted), Toast.LENGTH_SHORT).show()
            refresh()
        }

        binding.btnViewRequests.setOnClickListener {
            startActivity(Intent(this, RequestsListActivity::class.java))
        }

        binding.rvLevels.layoutManager = GridLayoutManager(this, 5)

        loadBannerAd()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val coins = PrefsManager.getCoins(this)
        binding.tvCoins.text = getString(R.string.coins_format, coins)

        binding.btnAdminBonus.visibility =
            if (PrefsManager.isAdmin(this)) android.view.View.VISIBLE else android.view.View.GONE

        binding.btnViewRequests.visibility =
            if (PrefsManager.isAdmin(this)) android.view.View.VISIBLE else android.view.View.GONE

        val totalLevels = QuestionRepository.totalLevels(this).let { if (it > 0) it else 100 }
        val unlocked = PrefsManager.getUnlockedLevel(this)

        binding.rvLevels.adapter = LevelAdapter(totalLevels, unlocked) { level ->
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra(QuizActivity.EXTRA_LEVEL, level)
            startActivity(intent)
        }
    }

    private fun loadBannerAd() {
        binding.adView.adUnitId = TEST_BANNER_UNIT_ID
        val density = resources.displayMetrics.density
        val adWidthPixels = resources.displayMetrics.widthPixels
        val adWidthDp = (adWidthPixels / density).toInt()
        binding.adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp))
        binding.adView.loadAd(AdRequest.Builder().build())
    }
}
