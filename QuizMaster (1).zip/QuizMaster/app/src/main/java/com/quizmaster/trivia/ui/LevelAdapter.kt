package com.quizmaster.trivia.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizmaster.trivia.databinding.ItemLevelBinding

class LevelAdapter(
    private val totalLevels: Int,
    private val unlockedLevel: Int,
    private val onLevelClick: (Int) -> Unit
) : RecyclerView.Adapter<LevelAdapter.LevelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): LevelViewHolder {
        val binding = ItemLevelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LevelViewHolder(binding)
    }

    override fun getItemCount(): Int = totalLevels

    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {
        val level = position + 1
        holder.bind(level)
    }

    inner class LevelViewHolder(private val binding: ItemLevelBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(level: Int) {
            binding.tvLevelNumber.text = level.toString()

            when {
                level < unlockedLevel -> {
                    // already completed
                    binding.levelBg.setBackgroundResource(com.quizmaster.trivia.R.drawable.bg_level_completed)
                    binding.ivLock.visibility = View.GONE
                    binding.tvLevelNumber.visibility = View.VISIBLE
                    binding.levelBg.isClickable = true
                    binding.levelBg.setOnClickListener { onLevelClick(level) }
                }
                level == unlockedLevel -> {
                    // next playable level
                    binding.levelBg.setBackgroundResource(com.quizmaster.trivia.R.drawable.bg_level_unlocked)
                    binding.ivLock.visibility = View.GONE
                    binding.tvLevelNumber.visibility = View.VISIBLE
                    binding.levelBg.isClickable = true
                    binding.levelBg.setOnClickListener { onLevelClick(level) }
                }
                else -> {
                    // locked
                    binding.levelBg.setBackgroundResource(com.quizmaster.trivia.R.drawable.bg_level_locked)
                    binding.ivLock.visibility = View.VISIBLE
                    binding.tvLevelNumber.visibility = View.GONE
                    binding.levelBg.isClickable = false
                    binding.levelBg.setOnClickListener(null)
                }
            }
        }
    }
}
