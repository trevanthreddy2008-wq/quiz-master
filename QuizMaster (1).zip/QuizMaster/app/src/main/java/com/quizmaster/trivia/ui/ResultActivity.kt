package com.quizmaster.trivia.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.quizmaster.trivia.R
import com.quizmaster.trivia.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL = "extra_level"
        const val EXTRA_SCORE = "extra_score"
        const val EXTRA_TOTAL = "extra_total"
        const val EXTRA_COINS_EARNED = "extra_coins_earned"
    }

    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val level = intent.getIntExtra(EXTRA_LEVEL, 1)
        val score = intent.getIntExtra(EXTRA_SCORE, 0)
        val total = intent.getIntExtra(EXTRA_TOTAL, 10)
        val coinsEarned = intent.getIntExtra(EXTRA_COINS_EARNED, 0)

        binding.tvScore.text = getString(R.string.score_format, score, total)
        binding.tvCoinsEarned.text = getString(R.string.coins_earned_format, coinsEarned)

        val isLastLevel = level >= 100
        if (isLastLevel) {
            binding.btnNextLevel.text = getString(R.string.all_levels_complete)
        } else {
            binding.btnNextLevel.text = getString(R.string.next_level)
        }

        binding.btnNextLevel.setOnClickListener {
            if (isLastLevel) {
                goToLevels()
            } else {
                val intent = Intent(this, QuizActivity::class.java)
                intent.putExtra(QuizActivity.EXTRA_LEVEL, level + 1)
                startActivity(intent)
                finish()
            }
        }

        binding.btnBackToLevels.setOnClickListener { goToLevels() }
    }

    private fun goToLevels() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intent)
        finish()
    }
}
