package com.quizmaster.trivia.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.quizmaster.trivia.R
import com.quizmaster.trivia.databinding.ItemAdminRequestBinding
import com.quizmaster.trivia.model.RedeemRequest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AdminRequestsAdapter(
    private var items: List<RedeemRequest>,
    private val onMarkComplete: (String) -> Unit
) : RecyclerView.Adapter<AdminRequestsAdapter.RequestViewHolder>() {

    private val dateFormat = SimpleDateFormat("MMM d, yyyy, h:mm a", Locale.getDefault())

    fun updateData(newItems: List<RedeemRequest>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): RequestViewHolder {
        val binding = ItemAdminRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RequestViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RequestViewHolder, position: Int) {
        holder.bind(items[position])
    }

    inner class RequestViewHolder(private val binding: ItemAdminRequestBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(request: RedeemRequest) {
            val context = binding.root.context

            binding.tvRequestId.text = request.requestId
            binding.tvContact.text = request.contactInfo
            binding.tvSubmittedTime.text = dateFormat.format(Date(request.timestampMillis))

            if (request.fulfilled) {
                binding.tvStatus.text = context.getString(R.string.status_fulfilled)
                binding.tvStatus.setTextColor(context.getColor(R.color.correct_green))
                binding.btnMarkComplete.visibility = View.GONE
            } else {
                binding.tvStatus.text = context.getString(R.string.status_pending)
                binding.tvStatus.setTextColor(context.getColor(R.color.primary))
                binding.btnMarkComplete.visibility = View.VISIBLE
                binding.btnMarkComplete.setOnClickListener {
                    onMarkComplete(request.requestId)
                }
            }
        }
    }
}
