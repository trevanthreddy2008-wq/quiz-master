package com.quizmaster.trivia.model

/**
 * A redemption request submitted by a player once they hit the coin
 * threshold. There is no backend - this just records locally that the
 * player asked, what contact info they gave, and whether they've since
 * told the app "I got my code". The actual code is sent by the app owner
 * by hand (email/WhatsApp), outside the app.
 */
data class RedeemRequest(
    val requestId: String,
    val contactInfo: String,
    val timestampMillis: Long,
    val coinsSpent: Int,
    val fulfilled: Boolean
) {
    companion object {
        const val RESPONSE_WINDOW_HOURS = 24
    }

    val dueByMillis: Long
        get() = timestampMillis + RESPONSE_WINDOW_HOURS * 60L * 60L * 1000L
}
