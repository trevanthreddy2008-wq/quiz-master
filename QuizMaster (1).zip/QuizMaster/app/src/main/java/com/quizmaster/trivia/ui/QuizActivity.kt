package com.quizmaster.trivia.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.quizmaster.trivia.R
import com.quizmaster.trivia.data.QuestionRepository
import com.quizmaster.trivia.databinding.ActivityQuizBinding
import com.quizmaster.trivia.model.Question
import com.quizmaster.trivia.utils.AdManager
import com.quizmaster.trivia.utils.PrefsManager

class QuizActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL = "extra_level"
        private const val ANSWER_REVEAL_DELAY_MS = 700L
    }

    private lateinit var binding: ActivityQuizBinding
    private var level: Int = 1
    private var questions: List<Question> = emptyList()
    private var currentIndex = 0
    private var correctCount = 0
    private var answerLocked = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var optionButtons: List<android.widget.Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        level = intent.getIntExtra(EXTRA_LEVEL, 1)
        questions = QuestionRepository.getQuestionsForLevel(this, level)

        binding.tvLevelLabel.text = getString(R.string.level_format, level)

        optionButtons = listOf(
            binding.btnOption0,
            binding.btnOption1,
            binding.btnOption2,
            binding.btnOption3
        )
        optionButtons.forEachIndexed { index, button ->
            button.setOnClickListener { onOptionSelected(index) }
        }

        AdManager.preload(this)

        if (questions.isEmpty()) {
            // Shouldn't happen with the bundled question bank, but guard anyway.
            finish()
            return
        }

        displayQuestion(0)
    }

    private fun displayQuestion(index: Int) {
        answerLocked = false
        val q = questions[index]

        binding.tvProgress.text = getString(R.string.question_progress_format, index + 1, questions.size)
        binding.tvCategory.text = q.category.uppercase()
        binding.tvQuestion.text = q.question

        q.options.forEachIndexed { i, optionText ->
            optionButtons[i].text = optionText
            optionButtons[i].setBackgroundResource(R.drawable.bg_option_default)
            optionButtons[i].isEnabled = true
        }

        binding.progressTrack.post {
            val fraction = index.toFloat() / questions.size
            val width = (binding.progressTrack.width * fraction).toInt()
            val params = binding.progressFill.layoutParams
            params.width = width
            binding.progressFill.layoutParams = params
        }
    }

    private fun onOptionSelected(selectedIndex: Int) {
        if (answerLocked) return
        answerLocked = true

        val q = questions[currentIndex]
        optionButtons.forEach { it.isEnabled = false }

        if (selectedIndex == q.correctIndex) {
            correctCount++
            optionButtons[selectedIndex].setBackgroundResource(R.drawable.bg_option_correct)
        } else {
            optionButtons[selectedIndex].setBackgroundResource(R.drawable.bg_option_wrong)
            optionButtons[q.correctIndex].setBackgroundResource(R.drawable.bg_option_correct)
        }

        handler.postDelayed({ advance() }, ANSWER_REVEAL_DELAY_MS)
    }

    private fun advance() {
        currentIndex++

        val atMilestone = currentIndex == 5 || currentIndex == questions.size
        if (atMilestone) {
            AdManager.showInterstitial(this) {
                PrefsManager.addCoins(this, 50)
                if (currentIndex >= questions.size) {
                    finishLevel()
                } else {
                    displayQuestion(currentIndex)
                }
            }
        } else {
            displayQuestion(currentIndex)
        }
    }

    private fun finishLevel() {
        PrefsManager.unlockLevel(this, level)

        val intent = Intent(this, ResultActivity::class.java)
        intent.putExtra(ResultActivity.EXTRA_LEVEL, level)
        intent.putExtra(ResultActivity.EXTRA_SCORE, correctCount)
        intent.putExtra(ResultActivity.EXTRA_TOTAL, questions.size)
        intent.putExtra(ResultActivity.EXTRA_COINS_EARNED, 100)
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
